======================
Themes and Widget Sets
======================

The WebContent/VAADIN directory contains Themes and Widgetsets.

------
Themes
------

Themes may be edited freely. They contain static images, CSS,
and layouts for Vaadin applications.

See http://dev.vaadin.com/wiki/DevDocs/StartingDevelopment for instructions for
installing GWT and compiling widgetsets for Vaadin development.
